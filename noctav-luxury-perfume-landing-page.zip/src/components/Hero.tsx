import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { site } from '../content/site';
import { StaggeredFade } from './motion/StaggeredFade';
import { useLenis } from '../context/LenisContext';
import { ArrowDown, Play, Pause, Compass } from 'lucide-react';

const EASE = [0.16, 1, 0.3, 1] as const;

export const Hero: React.FC = () => {
  const { scrollTo } = useLenis();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);

  const toggleVideoPlayback = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play();
        setIsPlaying(true);
      } else {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    }
  };

  return (
    <section className="relative w-full min-h-screen flex items-center justify-center overflow-hidden bg-[#010101]">
      {/* Background Video with Poster Fallback */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        <video
          ref={videoRef}
          autoPlay
          muted
          loop
          playsInline
          poster={site.hero.poster}
          className="w-full h-full object-cover object-center scale-105 filter brightness-75 contrast-125 transition-transform duration-1000 ease-out"
        >
          <source src={site.hero.videoUrl} type="video/mp4" />
          <img src={site.hero.poster} alt="Noctavé Noir Atmosphere" className="w-full h-full object-cover" />
        </video>

        {/* Noir Vignettes and Ambient Color Haze */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#010101] via-black/40 to-[#010101]/80 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#010101]/70 via-transparent to-[#010101]/70 pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(1,1,1,0.65)_100%)] pointer-events-none" />
        
        {/* Subtle Luxury Film Grain Effect */}
        <div 
          className="absolute inset-0 opacity-[0.035] pointer-events-none mix-blend-overlay"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
          }}
        />
      </div>

      {/* Main Hero Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-28 pb-20 flex flex-col items-center">
        {/* Chapter / House Badge */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.1, ease: EASE }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/[0.04] border border-white/10 backdrop-blur-md mb-8"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#E8B978] animate-pulse" />
          <span className="text-[11px] font-mono tracking-[0.25em] text-[#E8B978] uppercase">
            Haute Parfumerie Nocturne · MMXXVI
          </span>
        </motion.div>

        {/* Title Line 1: WITNESS THE */}
        <div className="overflow-hidden">
          <StaggeredFade
            text={site.hero.titleLine1}
            as="h1"
            className="font-garamond text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-[0.18em] sm:tracking-[0.22em] text-white font-light uppercase select-none"
            charClassName="inline-block hover:text-[#E8B978] transition-colors duration-300"
            delay={0.3}
            stagger={0.035}
          />
        </div>

        {/* Title Line 2: HIDDEN NOIR */}
        <div className="overflow-hidden mt-1 sm:mt-2">
          <StaggeredFade
            text={site.hero.titleLine2}
            as="h1"
            className="font-garamond italic text-5xl sm:text-7xl md:text-8xl lg:text-9xl tracking-[0.14em] sm:tracking-[0.18em] text-[#E8B978] font-normal uppercase select-none amber-text-glow"
            charClassName="inline-block"
            delay={0.65}
            stagger={0.04}
          />
        </div>

        {/* Editorial Subtitle Lines */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 1.1, ease: EASE }}
          className="mt-8 max-w-2xl text-center space-y-1.5"
        >
          <p className="text-sm sm:text-base md:text-lg text-neutral-300 font-light tracking-wide leading-relaxed">
            {site.hero.subtitleLine1}
          </p>
          <p className="text-sm sm:text-base md:text-lg text-neutral-400 font-light tracking-wide italic font-garamond text-base sm:text-lg md:text-xl">
            {site.hero.subtitleLine2}
          </p>
        </motion.div>

        {/* CTA and Ritual Actions */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.1, delay: 1.35, ease: EASE }}
          className="mt-10 sm:mt-12 flex flex-col sm:flex-row items-center gap-4 sm:gap-6"
        >
          <button
            onClick={() => scrollTo('#collection', { offset: -40 })}
            className="group relative px-8 py-4 rounded-full bg-[#E8B978] text-black font-mono text-xs uppercase tracking-[0.22em] font-medium transition-all duration-300 hover:bg-[#fff] hover:shadow-[0_0_30px_rgba(232,185,120,0.5)] overflow-hidden"
          >
            <span className="relative z-10 flex items-center gap-3">
              <span>{site.hero.cta}</span>
              <Compass className="w-3.5 h-3.5 transition-transform duration-500 group-hover:rotate-90 text-black" />
            </span>
          </button>

          <button
            onClick={() => scrollTo('#house', { offset: -40 })}
            className="group px-7 py-4 rounded-full liquid-glass hover:bg-white/10 text-white font-mono text-xs uppercase tracking-[0.2em] transition-all duration-300 border border-white/15 hover:border-white/40"
          >
            <span>The Noctavé House</span>
          </button>
        </motion.div>
      </div>

      {/* Floating Bottom Info Bar */}
      <div className="absolute bottom-6 left-0 right-0 z-20 px-6 sm:px-10 flex items-center justify-between text-neutral-400 text-[11px] font-mono tracking-widest uppercase">
        {/* Left: Origin & Coordinates */}
        <div className="hidden md:flex items-center gap-3">
          <span className="w-1.5 h-1.5 rounded-full bg-[#E8B978]/60" />
          <span>Paris 48.8566° N · Grasse 43.6602° N</span>
        </div>

        {/* Center: Scroll down trigger */}
        <button
          onClick={() => scrollTo('#collection', { offset: -40 })}
          className="mx-auto md:mx-0 flex flex-col items-center gap-2 group text-neutral-400 hover:text-[#E8B978] transition-colors"
        >
          <span className="text-[10px] tracking-[0.25em]">Chapter I — Collection</span>
          <ArrowDown className="w-3.5 h-3.5 animate-bounce group-hover:text-[#E8B978]" />
        </button>

        {/* Right: Video Play/Pause toggle */}
        <div className="hidden md:flex items-center gap-4">
          <button
            onClick={toggleVideoPlayback}
            className="flex items-center gap-2 hover:text-[#E8B978] transition-colors"
            title={isPlaying ? 'Pause Motion' : 'Play Motion'}
          >
            {isPlaying ? (
              <>
                <Pause className="w-3 h-3" />
                <span className="text-[10px]">Pause Motion</span>
              </>
            ) : (
              <>
                <Play className="w-3 h-3" />
                <span className="text-[10px]">Play Motion</span>
              </>
            )}
          </button>
        </div>
      </div>
    </section>
  );
};
