import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';

const EASE = [0.16, 1, 0.3, 1] as const;

interface StaggeredFadeProps {
  text: string;
  className?: string;
  charClassName?: string;
  delay?: number;
  stagger?: number;
  as?: 'h1' | 'h2' | 'h3' | 'span' | 'div';
}

export const StaggeredFade: React.FC<StaggeredFadeProps> = ({
  text,
  className = '',
  charClassName = '',
  delay = 0.2,
  stagger = 0.035,
  as = 'h1',
}) => {
  const shouldReduceMotion = useReducedMotion();
  const characters = Array.from(text);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: shouldReduceMotion ? 0 : stagger,
        delayChildren: delay,
      },
    },
  };

  const charVariants = {
    hidden: {
      opacity: 0,
      y: shouldReduceMotion ? 0 : 45,
      filter: shouldReduceMotion ? 'none' : 'blur(6px)',
    },
    visible: {
      opacity: 1,
      y: 0,
      filter: 'blur(0px)',
      transition: {
        duration: shouldReduceMotion ? 0.01 : 1.2,
        ease: EASE,
      },
    },
  };

  const Component = motion[as] as typeof motion.div;

  return (
    <Component
      className={`inline-flex flex-wrap overflow-hidden ${className}`}
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {characters.map((char, index) => (
        <motion.span
          key={`${char}-${index}`}
          variants={charVariants}
          className={`inline-block whitespace-pre ${charClassName}`}
        >
          {char}
        </motion.span>
      ))}
    </Component>
  );
};
